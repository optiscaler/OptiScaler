Real DLSSG is disabled in the menu on pre-Ada GPUs even when an external DLSSG compatibility mod is loaded. The same menu capability result can also cause the selected real implementation to fall back to a replacement.

This change allows the existing Real DLSSG selection on NVIDIA DLSS-capable GPUs when a loaded module exports both `DlssgProxy_Name` and `DlssgProxy_Role`. These identifiers were observed in the supplied compatibility proxy. Detection uses module exports rather than a filename so ASI loading and alternative proxy names are covered.

- Preserve the existing native architecture check and reuse the existing `supportsDlssg` result for the output option, replacement option, and fallback logic.
- Check loaded modules at most once per second, allowing late loading and eventual removal detection without a process snapshot every menu frame.
- Acquire a temporary module reference while inspecting exports and release all handles.
- Update the Real DLSSG tooltip to describe the additional selection condition.

This only grants menu availability. Export presence does not prove that the mod is enabled or that frame generation initializes successfully. It does not bypass runtime capability checks, modify GPU architecture reporting, load the mod, or add a backend.

Validation:

- `git diff --check` passed.
- A portable C++17 harness compiled the actual detection helper against mocked Windows loader APIs and exercised missing modules, both exports on the same module, late loading, unloading, a failed module reference, throttling, snapshot failure/retry, and handle cleanup.
- The reporter confirmed Real DLSSG operation in FS25 after an earlier binary menu unlock and loading their mod as an ASI. That is supporting evidence for the use case, not an in-game test of this source change.
- This source change has not been built with MSVC or tested in a Windows game. Please keep the PR in draft until those checks pass, including an RTX 30-series mod test and native RTX 40/50-series regression testing.

No third-party DLLs or user logs are included.
