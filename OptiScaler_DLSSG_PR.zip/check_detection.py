# Portable behavior check using mocked Windows loader APIs, not a Windows build.
import pathlib,subprocess,sys,tempfile
source=pathlib.Path(sys.argv[1]).read_text(encoding='utf-8-sig')
start=source.index('static bool HasLoadedDlssgCompatibilityMod()')
end=source.index('\nstatic std::string windowTitle',start)
helper=source[start:end]
harness=r'''
#include <chrono>
#include <thread>
#include <vector>
#include <cstring>
#include <cassert>
#include <iostream>
using HMODULE=void*;
using LPCWSTR=const wchar_t*;
using HANDLE=void*;
constexpr auto TH32CS_SNAPMODULE=8;
constexpr auto GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS=4;
const HANDLE INVALID_HANDLE_VALUE=reinterpret_cast<HANDLE>(-1);
struct MODULEENTRY32W { unsigned long dwSize; unsigned char* modBaseAddr; };
struct Module { bool name, role, unloaded=false; };
std::vector<Module> modules;
size_t cursor=0;
bool failSnapshot=false;
int snapshots=0,closed=0,held=0,released=0;
unsigned GetCurrentProcessId() { return 1; }
HANDLE CreateToolhelp32Snapshot(unsigned flags,unsigned id) {
 assert(flags==8 && id==1); ++snapshots;
 return failSnapshot ? INVALID_HANDLE_VALUE : reinterpret_cast<HANDLE>(1);
}
bool Module32FirstW(HANDLE, MODULEENTRY32W* e) {
 assert(e->dwSize==sizeof(*e)); cursor=0;
 if(modules.empty()) return false;
 e->modBaseAddr=reinterpret_cast<unsigned char*>(&modules[cursor]);return true;
}
bool Module32NextW(HANDLE, MODULEENTRY32W* e) {
 if(++cursor>=modules.size()) return false;
 e->modBaseAddr=reinterpret_cast<unsigned char*>(&modules[cursor]);return true;
}
bool GetModuleHandleExW(unsigned flags,LPCWSTR address,HMODULE* out) {
 assert(flags==4); auto* m=reinterpret_cast<const Module*>(address);
 if(m->unloaded) return false;
 ++held;*out=const_cast<Module*>(m);return true;
}
void FreeLibrary(HMODULE) { ++released; }
void CloseHandle(HANDLE h) { assert(h!=INVALID_HANDLE_VALUE);++closed; }
void* GetProcAddressMock(HMODULE h,const char* name) {
 auto* m=static_cast<Module*>(h);
 bool exists=std::strcmp(name,"DlssgProxy_Name")==0 ? m->name : m->role;
 return exists ? reinterpret_cast<void*>(1) : nullptr;
}
struct KernelBaseProxy { static auto GetProcAddress_() { return &GetProcAddressMock; } };
'''
harness+=helper
harness+=r'''
void expire() { std::this_thread::sleep_for(std::chrono::milliseconds(1050)); }
int main() {
 assert(!HasLoadedDlssgCompatibilityMod());
 assert(snapshots==1 && closed==1);
 modules={{true,true}};
 assert(!HasLoadedDlssgCompatibilityMod() && snapshots==1); // throttled
 expire();assert(HasLoadedDlssgCompatibilityMod()); // late load / arbitrary filename
 modules.clear();expire();assert(!HasLoadedDlssgCompatibilityMod()); // unload
 modules={{true,false},{false,true}};expire();assert(!HasLoadedDlssgCompatibilityMod());
 modules={{true,true,true}};expire();assert(!HasLoadedDlssgCompatibilityMod()); // unload race
 modules={{false,false},{true,true}};expire();assert(HasLoadedDlssgCompatibilityMod());
 failSnapshot=true;expire();assert(!HasLoadedDlssgCompatibilityMod());
 failSnapshot=false;expire();assert(HasLoadedDlssgCompatibilityMod());
 assert(held==released && closed==snapshots-1);
 std::cout<<"PASS: presence, both exports on same module, arbitrary filename, late load, unload, unload race, throttle, snapshot failure/retry, handle cleanup\n";
}
'''
with tempfile.TemporaryDirectory() as d:
 p=pathlib.Path(d);(p/'test.cpp').write_text(harness)
 subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
