# Draft PR package

Target: https://github.com/optiscaler/OptiScaler
Base: master, a4890db5b3c7c6918f4b35d0fd3318b42e2ccc66
Suggested title: Allow Real DLSSG selection with a loaded compatibility mod
Suggested branch: fix/real-dlssg-mod-detection
Status: prepared locally; no remote PR opened.

`real-dlssg-mod-detection.patch` changes only OptiScaler/menu/menu_common.cpp.
`PR_DESCRIPTION.md` is the prepared PR body.
`check_detection.py` is a portable behavioral harness for review; it is not part of the proposed source diff and is not a Windows integration test.

## Apply to your fork

Fork optiscaler/OptiScaler on GitHub, clone your fork, and create the suggested branch. Put the patch and PR description in a folder outside the checkout. From the checkout run, replacing the example paths with your actual extracted package paths:

```sh
git switch -c fix/real-dlssg-mod-detection
git apply --check /path/to/real-dlssg-mod-detection.patch
git apply /path/to/real-dlssg-mod-detection.patch
git diff --check
git add OptiScaler/menu/menu_common.cpp
git commit -m "Allow Real DLSSG selection with a loaded compatibility mod"
git push -u origin fix/real-dlssg-mod-detection
```

Open a DRAFT pull request from that branch to optiscaler/OptiScaler:master, using the supplied title and PR_DESCRIPTION.md. With an authenticated GitHub CLI, the equivalent final step is:

```sh
gh pr create --repo optiscaler/OptiScaler --base master --draft --title "Allow Real DLSSG selection with a loaded compatibility mod" --body-file /path/to/PR_DESCRIPTION.md
```

If upstream has changed, resolve any apply conflicts against the current source before committing. Do not upload the previously patched binary or the third-party mod DLL as the source change.

## Portable check

On a machine with Python 3 and g++:

```sh
python /path/to/check_detection.py OptiScaler/menu/menu_common.cpp
```

The harness uses mocked Windows APIs. A Windows build and in-game verification remain required before this is ready to merge.
